# FocusFlow

FocusFlow is a minimal, opinionated focus timer app built with Kotlin and Jetpack Compose. It combines a Pomodoro-style timer, task list, ambient sound choices, and daily/weekly stats.

## Features

- **Focus & break timer** with configurable durations
- **Task list** to attach sessions to and track session counts per task
- **Daily and weekly stats** of completed sessions (work vs break minutes)
- **Ambient sound selection** and volume control (playback left to platform integration)
- **Persisted settings** via DataStore Preferences

## Tech Stack

- Kotlin
- Jetpack Compose (Material 3)
- Navigation Compose
- ViewModel & Kotlin Coroutines
- DataStore (Preferences)

## Project Structure

```text
app/
  src/main/java/com/example/focusflow/
    FocusFlowApp.kt
    MainActivity.kt
    data/
      model/ (Task, Session, AppSettings, AmbientSound)
      TaskRepository.kt
      SessionRepository.kt
      SettingsRepository.kt
    viewmodel/
      TimerViewModel.kt
      TasksViewModel.kt
      StatsViewModel.kt
      SoundsViewModel.kt
      SettingsViewModel.kt
      Factories.kt
    ui/
      screens/
        TimerScreen.kt
        TasksScreen.kt
        StatsScreen.kt
        SoundsScreen.kt
        SettingsScreen.kt
      theme/
        Color.kt
        Theme.kt
        Type.kt
```

## Getting Started

1. **Clone the repository** (or copy this project structure into a new Android Studio project).
2. Ensure you have **Android Studio Iguana or newer** with:
   - Kotlin 1.9+
   - Compose Compiler Extension 1.5.11
3. Open the project in Android Studio.
4. Sync Gradle and run the `app` configuration on an emulator or device.

## Key Screens

### TimerScreen

- Central focus/break timer.
- Start **Work**, **Break**, or **Long break** sessions.
- Attach the current session to an existing task.
- Pause/resume and stop controls.

### TasksScreen

- Simple list of tasks with a checkbox to mark completion.
- "Sessions" counter per task increments whenever a work session finishes attached to that task.

### StatsScreen

- Aggregated **today** and **last 7 days** statistics.
- Shows total work and break minutes and total session count for the week.

### SoundsScreen

- List of ambient sound profiles (e.g., rain, forest, waves, brown noise).
- Choose one active profile and adjust global volume.
- Note: actual audio playback is not wired; this screen models selection and volume settings only.

### SettingsScreen

- Configure default **work**, **break**, and **long break** durations.
- Toggle auto-start of the next session after finishing.
- All values are persisted via DataStore.

## Architecture Notes

- **Repositories** (`TaskRepository`, `SessionRepository`, `SettingsRepository`) expose state as `StateFlow` or `Flow`.
- **ViewModels** collect and combine flows into immutable `UiState` data classes.
- UI is implemented in Jetpack Compose using Material 3 components and a warm red/teal color scheme.
- Navigation is handled by `NavHost` in `MainActivity` with a bottom navigation bar.

## Extending the App

- Wire ambient sounds using `MediaPlayer` or ExoPlayer, reacting to `SoundsViewModel` state.
- Persist tasks and sessions with Room instead of in-memory repositories.
- Implement true auto-start for next sessions using the `autoStartNext` flag in `AppSettings`.
- Add notifications when sessions complete or when it's time to resume work.

## License

This project is provided as a sample; integrate into your own project under the terms appropriate for your use case.
