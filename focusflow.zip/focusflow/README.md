# FocusFlow

FocusFlow is a minimal, opinionated focus timer app built with Kotlin and Jetpack Compose. It combines a Pomodoro-style timer, task list, ambient sound choices, and daily/weekly stats.

## Features

- Focus & break timer with configurable durations
- Task list to attach sessions to and track session counts per task
- Daily and weekly stats of completed sessions
- Ambient sound selection and volume control
- Persisted settings via DataStore

## Setup

1. Ensure you have Android Studio (Iguana or newer) installed.
2. Create a new **Empty Compose Activity** project or clone this repository structure.
3. Replace the generated project files with the ones in this JSON (respecting paths).
4. Sync Gradle and run the `app` configuration on an emulator or physical device.

## Screens Overview

- **TimerScreen** – Central focus/break timer, attach sessions to tasks.
- **TasksScreen** – Manage tasks and see how many sessions each has.
- **StatsScreen** – Daily and weekly breakdown of work and break minutes.
- **SoundsScreen** – Choose an ambient sound profile and volume.
- **SettingsScreen** – Configure work/break durations and auto-start behavior.

## Dependencies

- `androidx.compose.material3:material3`
- `androidx.navigation:navigation-compose`
- `androidx.lifecycle:lifecycle-viewmodel-compose`
- `androidx.datastore:datastore-preferences`

## Architecture

- MVVM with simple in-memory repositories for tasks and sessions.
- DataStore for persisted user settings.
- StateFlow-based UI state, collected in composables with `collectAsState()`.
- Single-activity navigation using `NavHost` and bottom navigation.

You can extend this base by persisting tasks/sessions with Room and by wiring real audio playback that reacts to the ambient sound settings.