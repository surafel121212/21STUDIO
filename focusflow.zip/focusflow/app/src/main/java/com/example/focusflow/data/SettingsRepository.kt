package com.example.focusflow.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.focusflow.data.model.AppSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "focusflow_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val WORK_MIN = intPreferencesKey("work_minutes")
        val BREAK_MIN = intPreferencesKey("break_minutes")
        val LONG_BREAK_MIN = intPreferencesKey("long_break_minutes")
        val AUTO_START = intPreferencesKey("auto_start_next")
        val SOUND_ID = stringPreferencesKey("sound_id")
        val SOUND_VOL = floatPreferencesKey("sound_volume")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            workDurationMinutes = prefs[Keys.WORK_MIN] ?: 25,
            breakDurationMinutes = prefs[Keys.BREAK_MIN] ?: 5,
            longBreakDurationMinutes = prefs[Keys.LONG_BREAK_MIN] ?: 15,
            autoStartNext = (prefs[Keys.AUTO_START] ?: 0) == 1,
            selectedSoundId = prefs[Keys.SOUND_ID],
            soundVolume = prefs[Keys.SOUND_VOL] ?: 0.4f
        )
    }

    suspend fun update(block: (AppSettings) -> AppSettings) {
        context.dataStore.edit { prefs ->
            val current = AppSettings(
                workDurationMinutes = prefs[Keys.WORK_MIN] ?: 25,
                breakDurationMinutes = prefs[Keys.BREAK_MIN] ?: 5,
                longBreakDurationMinutes = prefs[Keys.LONG_BREAK_MIN] ?: 15,
                autoStartNext = (prefs[Keys.AUTO_START] ?: 0) == 1,
                selectedSoundId = prefs[Keys.SOUND_ID],
                soundVolume = prefs[Keys.SOUND_VOL] ?: 0.4f
            )
            val updated = block(current)
            prefs[Keys.WORK_MIN] = updated.workDurationMinutes
            prefs[Keys.BREAK_MIN] = updated.breakDurationMinutes
            prefs[Keys.LONG_BREAK_MIN] = updated.longBreakDurationMinutes
            prefs[Keys.AUTO_START] = if (updated.autoStartNext) 1 else 0
            if (updated.selectedSoundId != null) {
                prefs[Keys.SOUND_ID] = updated.selectedSoundId
            }
            prefs[Keys.SOUND_VOL] = updated.soundVolume
        }
    }
}
