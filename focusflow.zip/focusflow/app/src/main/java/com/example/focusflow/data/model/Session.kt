package com.example.focusflow.data.model

import java.time.LocalDate
import java.time.LocalDateTime

enum class SessionType { WORK, BREAK }

data class Session(
    val id: Long,
    val taskId: String?,
    val type: SessionType,
    val startedAt: LocalDateTime,
    val completedAt: LocalDateTime,
    val durationMinutes: Int
) {
    val day: LocalDate = startedAt.toLocalDate()
}
