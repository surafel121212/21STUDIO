package com.example.focusflow.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.focusflow.data.SettingsRepository
import com.example.focusflow.viewmodel.SettingsViewModel
import com.example.focusflow.viewmodel.SettingsViewModelFactory

@Composable
fun SettingsScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val settingsViewModel: SettingsViewModel = viewModel(factory = SettingsViewModelFactory(SettingsRepository(context)))
    val settings by settingsViewModel.settings.collectAsState()

    var workText by remember(settings.workDurationMinutes) { mutableStateOf(settings.workDurationMinutes.toString()) }
    var breakText by remember(settings.breakDurationMinutes) { mutableStateOf(settings.breakDurationMinutes.toString()) }
    var longBreakText by remember(settings.longBreakDurationMinutes) { mutableStateOf(settings.longBreakDurationMinutes.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Durations (minutes)", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = workText,
                onValueChange = {
                    workText = it.filter { ch -> ch.isDigit() }
                    settingsViewModel.setDurations(workText.toIntOrNull() ?: settings.workDurationMinutes, settings.breakDurationMinutes, settings.longBreakDurationMinutes)
                },
                label = { Text("Work") },
                modifier = Modifier.weight(1f),
                keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = breakText,
                onValueChange = {
                    breakText = it.filter { ch -> ch.isDigit() }
                    settingsViewModel.setDurations(settings.workDurationMinutes, breakText.toIntOrNull() ?: settings.breakDurationMinutes, settings.longBreakDurationMinutes)
                },
                label = { Text("Break") },
                modifier = Modifier.weight(1f),
                keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = longBreakText,
            onValueChange = {
                longBreakText = it.filter { ch -> ch.isDigit() }
                settingsViewModel.setDurations(settings.workDurationMinutes, settings.breakDurationMinutes, longBreakText.toIntOrNull() ?: settings.longBreakDurationMinutes)
            },
            label = { Text("Long break") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Auto-start next session")
                Text("Automatically start the next work/break after finishing.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(
                checked = settings.autoStartNext,
                onCheckedChange = { settingsViewModel.setAutoStart(it) }
            )
        }
    }
}
