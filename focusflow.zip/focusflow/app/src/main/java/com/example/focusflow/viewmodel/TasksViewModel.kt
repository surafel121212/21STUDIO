package com.example.focusflow.viewmodel

import androidx.lifecycle.ViewModel
import com.example.focusflow.data.TaskRepository
import com.example.focusflow.data.model.Task
import kotlinx.coroutines.flow.StateFlow

class TasksViewModel(private val taskRepository: TaskRepository) : ViewModel() {
    val tasks: StateFlow<List<Task>> = taskRepository.tasks

    fun addTask(title: String) {
        taskRepository.addTask(title)
    }

    fun toggleCompleted(id: String) {
        taskRepository.toggleTaskCompleted(id)
    }
}
