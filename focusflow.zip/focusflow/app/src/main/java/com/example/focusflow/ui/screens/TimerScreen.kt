package com.example.focusflow.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.focusflow.data.SessionRepository
import com.example.focusflow.data.SettingsRepository
import com.example.focusflow.data.TaskRepository
import com.example.focusflow.data.model.Task
import com.example.focusflow.viewmodel.TaskViewModelFactory
import com.example.focusflow.viewmodel.TasksViewModel
import com.example.focusflow.viewmodel.TimerPhase
import com.example.focusflow.viewmodel.TimerViewModel

@Composable
fun TimerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val timerViewModel: TimerViewModel = viewModel(
        factory = TimerViewModelFactory(
            SessionRepository(),
            TaskRepository(),
            SettingsRepository(context)
        )
    )
    val tasksViewModel: TasksViewModel = viewModel(
        factory = TaskViewModelFactory(TaskRepository())
    )

    val timerState by timerViewModel.uiState.collectAsState()
    val taskList by tasksViewModel.tasks.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (timerState.isWork) "Focus" else "Break",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = formatTime(timerState.remainingSeconds.takeIf { it > 0 } ?: timerState.totalSeconds),
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { timerViewModel.startWork() }) {
                        Text("Work")
                    }
                    Button(onClick = { timerViewModel.startBreak(false) }) {
                        Text("Break")
                    }
                    OutlinedButton(onClick = { timerViewModel.startBreak(true) }) {
                        Text("Long break")
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (timerState.phase) {
                        is TimerPhase.Running -> {
                            OutlinedButton(onClick = { timerViewModel.togglePause() }) {
                                Text("Pause")
                            }
                            OutlinedButton(onClick = { timerViewModel.stop() }) {
                                Text("Stop")
                            }
                        }
                        is TimerPhase.Paused -> {
                            Button(onClick = { timerViewModel.togglePause() }) {
                                Text("Resume")
                            }
                            OutlinedButton(onClick = { timerViewModel.stop() }) {
                                Text("Stop")
                            }
                        }
                        is TimerPhase.Idle -> {
                            Text("Timer idle", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Attach to task",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))
        if (taskList.isEmpty()) {
            Text(
                text = "Add tasks in the Tasks tab to link focus sessions.",
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            TaskSelectionRow(tasks = taskList, selectedTaskId = timerState.attachedTaskId, onSelect = {
                timerViewModel.attachTask(it)
            })
        }
    }
}

@Composable
private fun TaskSelectionRow(tasks: List<Task>, selectedTaskId: String?, onSelect: (String?) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            SegmentedButtonRow {
                SegmentedButton(
                    selected = selectedTaskId == null,
                    onClick = { onSelect(null) },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = tasks.size + 1)
                ) {
                    Text("None")
                }
            }
        }
        items(tasks) { task ->
            SegmentedButtonRow {
                SegmentedButton(
                    selected = selectedTaskId == task.id,
                    onClick = { onSelect(task.id) },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = tasks.size + 1)
                ) {
                    Text(task.title)
                }
            }
        }
    }
}

private fun formatTime(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%02d:%02d".format(m, s)
}
