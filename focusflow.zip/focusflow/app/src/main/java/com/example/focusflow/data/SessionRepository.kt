package com.example.focusflow.data

import com.example.focusflow.data.model.Session
import com.example.focusflow.data.model.SessionType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.LocalDateTime

class SessionRepository {
    private val _sessions = MutableStateFlow<List<Session>>(emptyList())
    val sessions: StateFlow<List<Session>> = _sessions

    private var lastId: Long = 0L

    fun recordSession(taskId: String?, type: SessionType, durationMinutes: Int) {
        val now = LocalDateTime.now()
        val session = Session(
            id = ++lastId,
            taskId = taskId,
            type = type,
            startedAt = now.minusMinutes(durationMinutes.toLong()),
            completedAt = now,
            durationMinutes = durationMinutes
        )
        _sessions.value = _sessions.value + session
    }

    fun dailyStats(date: LocalDate) = sessions.map { list ->
        list.filter { it.day == date }
    }

    fun weeklyStats(endDate: LocalDate) = sessions.map { list ->
        val start = endDate.minusDays(6)
        list.filter { it.day >= start && it.day <= endDate }
    }
}
