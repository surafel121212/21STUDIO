package com.example.focusflow.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focusflow.data.SessionRepository
import com.example.focusflow.data.model.Session
import com.example.focusflow.data.model.SessionType
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

data class StatsUiState(
    val todaySessions: List<Session> = emptyList(),
    val weekSessions: List<Session> = emptyList()
) {
    val todayWorkMinutes: Int get() = todaySessions.filter { it.type == SessionType.WORK }.sumOf { it.durationMinutes }
    val todayBreakMinutes: Int get() = todaySessions.filter { it.type == SessionType.BREAK }.sumOf { it.durationMinutes }
    val weekWorkMinutes: Int get() = weekSessions.filter { it.type == SessionType.WORK }.sumOf { it.durationMinutes }
    val weekBreakMinutes: Int get() = weekSessions.filter { it.type == SessionType.BREAK }.sumOf { it.durationMinutes }
}

class StatsViewModel(sessionRepository: SessionRepository) : ViewModel() {
    private val today = LocalDate.now()
    private val todayFlow = sessionRepository.dailyStats(today)
    private val weekFlow = sessionRepository.weeklyStats(today)

    val uiState: StateFlow<StatsUiState> = combine(todayFlow, weekFlow) { todayList, weekList ->
        StatsUiState(todayList, weekList)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, StatsUiState())
}
