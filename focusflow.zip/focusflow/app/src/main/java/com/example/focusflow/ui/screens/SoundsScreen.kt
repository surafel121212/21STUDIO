package com.example.focusflow.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.focusflow.data.SettingsRepository
import com.example.focusflow.viewmodel.SoundsViewModel
import com.example.focusflow.viewmodel.SoundsViewModelFactory

@Composable
fun SoundsScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val soundsViewModel: SoundsViewModel = viewModel(factory = SoundsViewModelFactory(SettingsRepository(context)))
    val uiState by soundsViewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Ambient sounds",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text("Choose a background sound to play during sessions.")
        Spacer(modifier = Modifier.height(16.dp))
        uiState.sounds.forEach { sound ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = uiState.selectedSoundId == sound.id,
                        onClick = { soundsViewModel.selectSound(sound.id) },
                        role = Role.RadioButton
                    )
                    .padding(vertical = 6.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = uiState.selectedSoundId == sound.id,
                    onClick = { soundsViewModel.selectSound(sound.id) }
                )
                Column(Modifier.padding(start = 8.dp)) {
                    Text(sound.name, fontWeight = FontWeight.SemiBold)
                    Text(sound.description, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text("Volume", modifier = Modifier.weight(1f))
            Slider(
                value = uiState.volume,
                onValueChange = { soundsViewModel.updateVolume(it) },
                modifier = Modifier.weight(3f)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Note: Sound playback wiring is left to the platform layer (MediaPlayer/ExoPlayer).")
    }
}
