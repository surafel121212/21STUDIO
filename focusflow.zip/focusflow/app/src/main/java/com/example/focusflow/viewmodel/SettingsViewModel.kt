package com.example.focusflow.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focusflow.data.SettingsRepository
import com.example.focusflow.data.model.AppSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val settingsRepository: SettingsRepository) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    fun setDurations(work: Int, brk: Int, longBreak: Int) {
        viewModelScope.launch {
            settingsRepository.update { it.copy(
                workDurationMinutes = work.coerceIn(5, 120),
                breakDurationMinutes = brk.coerceIn(1, 60),
                longBreakDurationMinutes = longBreak.coerceIn(5, 60)
            ) }
        }
    }

    fun setAutoStart(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.update { it.copy(autoStartNext = enabled) }
        }
    }
}
