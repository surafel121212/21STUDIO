package com.example.focusflow.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryRed = Color(0xFFFF6B6B)
val PrimaryDark = Color(0xFFB33939)
val SecondaryTeal = Color(0xFF20C997)
val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB3B3B3)
