package com.example.focusflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.BarChart
import androidx.compose.material3.icons.filled.Settings
import androidx.compose.material3.icons.filled.Timeline
import androidx.compose.material3.icons.filled.Timer
import androidx.compose.material3.icons.filled.VolumeUp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.focusflow.ui.screens.SettingsScreen
import com.example.focusflow.ui.screens.SoundsScreen
import com.example.focusflow.ui.screens.StatsScreen
import com.example.focusflow.ui.screens.TasksScreen
import com.example.focusflow.ui.screens.TimerScreen
import com.example.focusflow.ui.theme.FocusFlowTheme

sealed class BottomNavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Timer : BottomNavItem("timer", "Timer", Icons.Filled.Timer)
    data object Tasks : BottomNavItem("tasks", "Tasks", Icons.Filled.Timeline)
    data object Stats : BottomNavItem("stats", "Stats", Icons.Filled.BarChart)
    data object Sounds : BottomNavItem("sounds", "Sounds", Icons.Filled.VolumeUp)
    data object Settings : BottomNavItem("settings", "Settings", Icons.Filled.Settings)
}

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FocusFlowTheme {
                val navController = rememberNavController()
                val items = listOf(
                    BottomNavItem.Timer,
                    BottomNavItem.Tasks,
                    BottomNavItem.Stats,
                    BottomNavItem.Sounds,
                    BottomNavItem.Settings
                )

                Scaffold(
                    bottomBar = {
                        val navBackStackEntry by navController.currentBackStackEntryAsState()
                        val currentDestination = navBackStackEntry?.destination
                        NavigationBar {
                            items.forEach { item ->
                                NavigationBarItem(
                                    icon = { androidx.compose.material3.Icon(item.icon, contentDescription = item.label) },
                                    label = { Text(item.label) },
                                    selected = currentDestination.isTopLevelDestinationInHierarchy(item.route),
                                    onClick = {
                                        navController.navigate(item.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = BottomNavItem.Timer.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(BottomNavItem.Timer.route) {
                            TimerScreen()
                        }
                        composable(BottomNavItem.Tasks.route) {
                            TasksScreen()
                        }
                        composable(BottomNavItem.Stats.route) {
                            StatsScreen()
                        }
                        composable(BottomNavItem.Sounds.route) {
                            SoundsScreen()
                        }
                        composable(BottomNavItem.Settings.route) {
                            SettingsScreen()
                        }
                    }
                }
            }
        }
    }
}

private fun NavDestination?.isTopLevelDestinationInHierarchy(route: String): Boolean {
    var currentDestination = this
    while (currentDestination != null) {
        if (currentDestination.route == route) return true
        currentDestination = currentDestination.parent
    }
    return false
}
