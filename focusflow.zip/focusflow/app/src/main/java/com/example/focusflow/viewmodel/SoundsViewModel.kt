package com.example.focusflow.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focusflow.data.SettingsRepository
import com.example.focusflow.data.model.AmbientSound
import com.example.focusflow.data.model.AppSettings
import com.example.focusflow.data.model.defaultAmbientSounds
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SoundsUiState(
    val sounds: List<AmbientSound> = defaultAmbientSounds,
    val selectedSoundId: String? = null,
    val volume: Float = 0.4f
)

class SoundsViewModel(private val settingsRepository: SettingsRepository) : ViewModel() {

    private val soundsFlow = MutableStateFlow(defaultAmbientSounds)
    private val settingsFlow = settingsRepository.settingsFlow

    val uiState: StateFlow<SoundsUiState> = combine(soundsFlow, settingsFlow) { sounds, settings: AppSettings ->
        SoundsUiState(
            sounds = sounds,
            selectedSoundId = settings.selectedSoundId,
            volume = settings.soundVolume
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, SoundsUiState())

    fun selectSound(id: String?) {
        viewModelScope.launch {
            settingsRepository.update { it.copy(selectedSoundId = id) }
        }
    }

    fun updateVolume(volume: Float) {
        viewModelScope.launch {
            settingsRepository.update { it.copy(soundVolume = volume.coerceIn(0f, 1f)) }
        }
    }
}
