package com.example.focusflow.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.focusflow.data.SessionRepository
import com.example.focusflow.data.SettingsRepository
import com.example.focusflow.data.TaskRepository
import com.example.focusflow.data.model.AppSettings
import com.example.focusflow.data.model.SessionType
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class TimerPhase { object Idle : TimerPhase(); object Running : TimerPhase(); object Paused : TimerPhase() }

data class TimerUiState(
    val remainingSeconds: Int = 0,
    val totalSeconds: Int = 0,
    val isWork: Boolean = true,
    val phase: TimerPhase = TimerPhase.Idle,
    val attachedTaskId: String? = null,
    val settings: AppSettings = AppSettings()
)

class TimerViewModel(
    private val sessionRepository: SessionRepository,
    private val taskRepository: TaskRepository,
    settingsRepository: SettingsRepository
) : ViewModel() {

    private val _remainingSeconds = MutableStateFlow(0)
    private val _totalSeconds = MutableStateFlow(0)
    private val _isWork = MutableStateFlow(true)
    private val _phase = MutableStateFlow<TimerPhase>(TimerPhase.Idle)
    private val _attachedTaskId = MutableStateFlow<String?>(null)

    val uiState: StateFlow<TimerUiState> = combine(
        _remainingSeconds,
        _totalSeconds,
        _isWork,
        _phase,
        _attachedTaskId,
        settingsRepository.settingsFlow
    ) { rem, total, isWork, phase, taskId, settings ->
        TimerUiState(
            remainingSeconds = rem,
            totalSeconds = total,
            isWork = isWork,
            phase = phase,
            attachedTaskId = taskId,
            settings = settings
        )
    }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Eagerly, TimerUiState())

    private var timerJob: Job? = null

    fun attachTask(taskId: String?) {
        _attachedTaskId.value = taskId
    }

    fun startWork() {
        startTimer(work = true)
    }

    fun startBreak(long: Boolean = false) {
        startTimer(work = false, longBreak = long)
    }

    private fun startTimer(work: Boolean, longBreak: Boolean = false) {
        viewModelScope.launch {
            val settings = uiState.value.settings
            val minutes = if (work) settings.workDurationMinutes else if (longBreak) settings.longBreakDurationMinutes else settings.breakDurationMinutes
            _totalSeconds.value = minutes * 60
            _remainingSeconds.value = minutes * 60
            _isWork.value = work
            _phase.value = TimerPhase.Running
            timerJob?.cancel()
            timerJob = viewModelScope.launch {
                while (_remainingSeconds.value > 0 && _phase.value == TimerPhase.Running) {
                    delay(1000)
                    _remainingSeconds.value -= 1
                }
                if (_remainingSeconds.value == 0 && _phase.value == TimerPhase.Running) {
                    onTimerFinished(minutes)
                }
            }
        }
    }

    fun togglePause() {
        when (_phase.value) {
            is TimerPhase.Running -> _phase.value = TimerPhase.Paused
            is TimerPhase.Paused -> _phase.value = TimerPhase.Running
            else -> Unit
        }
    }

    fun stop() {
        timerJob?.cancel()
        _phase.value = TimerPhase.Idle
        _remainingSeconds.value = 0
        _totalSeconds.value = 0
    }

    private fun onTimerFinished(durationMinutes: Int) {
        val isWork = _isWork.value
        val taskId = _attachedTaskId.value
        sessionRepository.recordSession(taskId, if (isWork) SessionType.WORK else SessionType.BREAK, durationMinutes)
        if (isWork && taskId != null) {
            taskRepository.incrementSessionCount(taskId)
        }
        _phase.value = TimerPhase.Idle
        _remainingSeconds.value = 0
        _totalSeconds.value = 0
    }
}
