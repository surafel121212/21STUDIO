package com.example.focusflow

import android.app.Application

class FocusFlowApp : Application()
