package com.example.focusflow.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class AmbientSound(
    val id: String,
    val name: String,
    val description: String
)

val defaultAmbientSounds = listOf(
    AmbientSound("rain", "Gentle Rain", "Soft rain on a window"),
    AmbientSound("forest", "Forest Birds", "Morning forest ambience"),
    AmbientSound("waves", "Ocean Waves", "Slow rolling sea waves"),
    AmbientSound("brown_noise", "Brown Noise", "Low, warm noise for deep focus")
)
