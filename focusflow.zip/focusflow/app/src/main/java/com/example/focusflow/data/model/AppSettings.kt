package com.example.focusflow.data.model

import androidx.compose.runtime.Immutable

@Immutable
data class AppSettings(
    val workDurationMinutes: Int = 25,
    val breakDurationMinutes: Int = 5,
    val longBreakDurationMinutes: Int = 15,
    val autoStartNext: Boolean = false,
    val selectedSoundId: String? = null,
    val soundVolume: Float = 0.4f
)
