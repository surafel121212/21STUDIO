package com.example.focusflow.data

import com.example.focusflow.data.model.Task
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class TaskRepository {
    private val _tasks = MutableStateFlow<List<Task>>(emptyList())
    val tasks: StateFlow<List<Task>> = _tasks

    fun addTask(title: String) {
        if (title.isBlank()) return
        _tasks.update { list ->
            list + Task(title = title.trim())
        }
    }

    fun toggleTaskCompleted(id: String) {
        _tasks.update { list ->
            list.map { task ->
                if (task.id == id) task.copy(isCompleted = !task.isCompleted) else task
            }
        }
    }

    fun incrementSessionCount(id: String) {
        _tasks.update { list ->
            list.map { task ->
                if (task.id == id) task.copy(sessionCount = task.sessionCount + 1) else task
            }
        }
    }
}
